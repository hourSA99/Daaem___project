package com.mycompany.project;
public class Main_menu extends Menu{
 
  Main_menu(){
   
 
    }
 
 
    public Main_menu(double price, String nameOfItem, String discription, int orderid) {
 
        super(price, nameOfItem, discription, orderid);
 
    }
 
  
 
    @Override
 
    public void display(){
 
        System.out.println("Item Name\t Description \t\t"+" Price\t ");
 
        System.out.println(super.getNameOfItem()+" \t "+super.getDiscription()+" \t "+super.getPrice());
 
        
 
    }
 
}